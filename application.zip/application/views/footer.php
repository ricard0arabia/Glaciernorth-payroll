     
          </div>

<div id="footer">
      <div class="container">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.0
          </div>
          <strong>
            Copyright &copy; 2015-2016 <a href="#" onclick="promotion();">Bored Student Developer Studios</a>.</strong> All rights reserved.
      </div>
    </div>

 

    <!-- 
  

   

 
    <script src="<?php echo base_url()?>css/blueprint/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="<?php echo base_url()?>css/blueprint/plugins/morris/morris.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.3/moment.js"></script>

   
  
   <script src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.1/js/bootstrap-datepicker.min.js" > </script>



   
        

    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>

    <script src="https://rawgit.com/seankenny/fullcalendar/v2/dist/fullcalendar.js"></script>




    <script src='<?php echo base_url()?>css/blueprint/jquery-fullcalendar-crud-master/js/bootstrap-colorpicker.min.js'></script>

 
    </script>
    <script type = "text/javascript"src='<?php echo base_url()?>css/blueprint/jquery-fullcalendar-crud-master/js/main.js'></script>

      <!--  <script type='text/javascript' src="<?php echo base_url(); ?>css/blueprint/materialize/js/materialize.min.js"></script>


    <!-- ======================================= Adapted resources =============================== -->

</body>

</html>
