<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Glacier Payroll System</title>

   <link rel="icon" href="<?php echo base_url('assets/img/favico.ico') ?>"> 
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.css')?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/datatables/css/dataTables.bootstrap.css')?>" rel="stylesheet">
  
   <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.1/css/bootstrap-datepicker3.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>


<body>

   <div class="navbar navbar-inverse" role="navigation">
  
  <div class="navbar-header">
      
         <?php if($_SESSION['userLevel'] == 1) { ?>

              <a href = "<?php echo site_url()."dashboard"; ?>"class="navbar-brand"><h5>Accountant Portal</h5></a><?php } elseif ($_SESSION['userLevel'] == 2) { ?>

              <a href = "<?php echo site_url()."dashboard"; ?>"class="navbar-brand">HR Portal</a>
               <?php } else { ?>

              <a href = "<?php echo site_url()."dashboard"; ?>"class="navbar-brand"><h5>Employee Portal</h5></a>

               <?php } ?>
  </div>
                
         
 <div class="collapse navbar-collapse">
             
             <ul class="nav navbar-nav">


                        <!-- _______________Profile________________  -->

                <?php if($this->uri->segment(1) == "userprofile" || $this->uri->segment(1) == "settings") { ?> <li  class = "active" > <?php }else { ?>
                 <li> <?php } ?> <a  class="waves-effect waves-default btn-small"  href="<?php echo site_url()."userprofile"; ?>"> <span class="glyphicon glyphicon-user"></span>&nbsp;&nbsp;Profile</a></li>


                             <!-- _______________time________________  -->

                    <?php if($this->uri->segment(1) == "time" ) { ?> <li  class = "active" > <?php } else { ?>
                 <li> <?php } ?>
                    <a  class="waves-effect waves-default btn-small"  href="<?php if($_SESSION['userLevel'] == 2) {  echo site_url(). "time/timesheet"; } else {echo site_url(). "time/timelog";} ?>"> <span class="glyphicon glyphicon-list-alt"></span>&nbsp;&nbsp;Time </a></li>

                        <!-- _______________Request________________  -->

                 <li class="dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle active">Requests<b class="caret"></b></a>
                   <ul class="dropdown-menu">
                    <li class="dropdown-header">Leaves</li>              
            <li><a href="<?php echo site_url()."leave"; ?>">List of Leave Requests</a></li>
                   <li role="separator" class="divider"></li>
                    <li class="dropdown-header">Overtime</li>
          <li><a href="<?php echo site_url()."overtime"; ?>">List of OT Requests</a></li>
          <li role="separator" class="divider"></li>
                    <li class="dropdown-header">Shift Change</li>
          <li><a href="<?php echo site_url()."shiftchange"; ?>">List of Shift requests</a></li>
                   </ul>
                    </li>

<!-- *****************************Accountant ************************************************* -->

                 <?php if($_SESSION['userLevel'] == 1) { ?>

                   <?php if($this->uri->segment(1) == "employees" || $this->uri->segment(1) == "loan" || $this->uri->segment(1) == "shift" || $this->uri->segment(1) == "leave" || $this->uri->segment(1) == "overtime") { ?> <li  class = "active" > <?php }else { ?>
                 <li> <?php } ?> <a  class="waves-effect waves-default btn-small"  href="<?php echo site_url()."employees"; ?>"> <span class="glyphicon glyphicon-list-alt"></span>&nbsp;&nbsp;Employee Masterfile</a></li>
                  <?php } ?>
<!-- *****************************      Hr      ************************************************* -->

                  <?php if($_SESSION['userLevel'] == 2) { ?>

                          <!-- _______________Approvals________________  -->

                  <?php if($this->uri->segment(1) == "approvals" ) { ?> <li  class = "active" > <?php } else { ?>
                 <li> <?php } ?>
                   <a  class="waves-effect waves-default btn-small"  href="<?php echo site_url(). "approvals/leave"; ?>"> <span class="glyphicon glyphicon-list-alt"></span>&nbsp;&nbsp;Approvals </a></li>


                            <!-- _______________Employees________________  -->

                     <?php if($this->uri->segment(1) == "employees" ) { ?> <li  class = "active" > <?php } else { ?>
                 <li> <?php } ?> <a  class="waves-effect waves-default btn-small"  href="<?php echo site_url(). "employees"; ?>"> <span class="glyphicon glyphicon-list-alt"></span>&nbsp;&nbsp;Employees </a></li>
                                   
                  <?php } ?>

         <!-- *****************************    Employee    ****************************** -->
                

                        
                  <?php if($this->uri->segment(1) == "compensation" ) { ?> <li  class = "active" > <?php }else { ?>
                <li> <?php } ?><a  class="waves-effect waves-default btn-small"  href="<?php if($_SESSION['userLevel'] == 1) {  echo site_url(). "compensation/payperiod"; } else {echo site_url(). "compensation/payslip";} ?>"><span class="glyphicon glyphicon-credit-card"></span>&nbsp;&nbsp;Compensation</a></li>



                    <li class="dropdown">
                  <a href="#" data-toggle="dropdown" class="dropdown-toggle">Options <b class="caret"></b></a>
                    <ul class="dropdown-menu">

                     <li ><a href="<?php echo site_url()."settings"; ?>" >Settings</a></li>
                      <li><a href="<?php echo site_url()."userprofile"; ?>" >Profile</a>
                      <li><a href="<?php echo site_url()."session/logout";?>">Sign out</a></li>         
                     </ul>
                    </li>
                  
              </ul>        

    
          </div>
     </div>

       <!-- jQuery -->
  <script src="<?php echo base_url('assets/jquery/jquery-2.1.4.min.js')?>"></script>
<script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
<script src="<?php echo base_url('assets/datatables/js/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assets/datatables/js/dataTables.bootstrap.js')?>"></script>
<script src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.1/js/bootstrap-datepicker.min.js" > </script>
  <script src="<?php echo base_url()?>css/blueprint/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url()?>css/blueprint/bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>
 
        
       <div class = "row">
         
                                 <?php echo $mainCont; ?>
                          
             
          </div>

<div id="footer">
      <div class="container">
        <div class="pull-right hidden-xs">
            <b>Version</b> 1.0.0
          </div>
          <strong>
            Copyright &copy; 2015-2016 <a href="#" onclick="promotion();">Bored Student Developer Studios</a>.</strong> All rights reserved.
      </div>
    </div>

 

    <!-- 
  

   

 
    <script src="<?php echo base_url()?>css/blueprint/bower_components/datatables/media/js/jquery.dataTables.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="<?php echo base_url()?>css/blueprint/plugins/morris/morris.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.3/moment.js"></script>

   
  
   <script src= "https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.1/js/bootstrap-datepicker.min.js" > </script>



   
        

    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>

    <script src="https://rawgit.com/seankenny/fullcalendar/v2/dist/fullcalendar.js"></script>




    <script src='<?php echo base_url()?>css/blueprint/jquery-fullcalendar-crud-master/js/bootstrap-colorpicker.min.js'></script>

 
    </script>
    <script type = "text/javascript"src='<?php echo base_url()?>css/blueprint/jquery-fullcalendar-crud-master/js/main.js'></script>

      <!--  <script type='text/javascript' src="<?php echo base_url(); ?>css/blueprint/materialize/js/materialize.min.js"></script>


    <!-- ======================================= Adapted resources =============================== -->

</body>

</html>
